package org.example;

import static org.junit.Assert.*;
import org.junit.Test;

public class AppTest {

    @Test
    public void testGetClientNameFromValidID() {
        int validID = 2;
        String clientName = getClientNameByID(validID);
        assertEquals("DEF FOODS", clientName);
    }

    @Test
    public void testGetClientNameFromInvalidID() {
        int invalidID = 7;
        String clientName = getClientNameByID(invalidID);
        assertNull(clientName);
    }

    private String getClientNameByID(int id) {
        for (Clients client : Clients.values()) {
            if (client.getClient_id() == id) {
                return client.getClient_name();
            }
        }
        return null;
    }

    @Test
    public void testGetProductNameFromValidID() {
        int validID = 1;
        String productName = getProductNameByID(validID);
        assertEquals("Danish Muffin", productName);
    }

    @Test
    public void testGetProductNameFromInvalidID() {
        int invalidID = 5;
        String productName = getProductNameByID(invalidID);
        assertNull(productName);
    }

    private String getProductNameByID(int id) {
        for (Products product : Products.values()) {
            if (product.getProduct_id() == id) {
                return product.getProduct_name();
            }
        }
        return null;
    }
}
