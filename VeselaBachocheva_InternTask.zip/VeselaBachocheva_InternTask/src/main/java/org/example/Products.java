package org.example;

public enum Products {
    MUFFIN(1, "Danish Muffin"),
    CAKE(2, "Granny’s Cup Cake"),
    CROISSANT(3, "Frenchy’s Croissant"),
    CHIPS(4, "Crispy chips");


    private int product_id;
    private String product_name;

    Products(int product_id, String product_name) {
        this.product_id = product_id;
        this.product_name = product_name;
    }

    public int getProduct_id() {
        return this.product_id;
    }

    public String getProduct_name() {
        return this.product_name;
    }


}
