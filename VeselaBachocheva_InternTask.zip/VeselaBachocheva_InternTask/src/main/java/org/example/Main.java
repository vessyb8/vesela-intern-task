package org.example;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String purchase = scanner.nextLine();
        String[] purchaseDetail = purchase.split(",");

        int quantity = 0;
        double standartUnitPrice = 0;
        double promUnitPrice = 0;
        double priceOrderedProducts = 0;
        double lineTotal = 0;
        double totalPriceBefClDisc=0;
        int basicClDisc = 0;
        double basicClDiscPrice = 0;
        int additionalVolDisc = 0;
        double additionalVolDiscPrice = 0;
        double orderTotalAmount = 0;

        String productName = "";

        int productID = 0;
        int clientID = Integer.parseInt(purchaseDetail[0]);

        if (clientID > 0 && clientID <= 5){
            for (Clients clients : Clients.values()
            ) {
                if (clients.getClient_id() == clientID) {
                    clients.getClient_name();
                    System.out.println("Client:     " + clients.getClient_name());
                }
            }
            System.out.printf("%n%-20s | %-8s | %19s | %6s | %22s %n", "Product", "Quantity", "Standart Unit Price","Promotional Unit Price","Line Total");

            for (int i = 1; i < purchaseDetail.length; i++) {
                String[] productDetail = purchaseDetail[i].split("=");
                productID = Integer.parseInt(productDetail[0]);
                quantity = Integer.parseInt(productDetail[1]);

                if (productID > 0 && productID <= 4){
                    switch (productID) {
                        case 1 -> {
                            standartUnitPrice = Math.round((0.52 * 1.8) * 100.0) / 100.0;
                            promUnitPrice = 0;
                            priceOrderedProducts = standartUnitPrice * quantity;
                            lineTotal = priceOrderedProducts - promUnitPrice;
                        }
                        case 2 -> {
                            standartUnitPrice = Math.round((0.38 * 2.2) * 100.0) / 100.0;
                            promUnitPrice = standartUnitPrice - standartUnitPrice * 0.3;
                            priceOrderedProducts = standartUnitPrice * quantity;
                            lineTotal = priceOrderedProducts - promUnitPrice;
                        }
                        case 3 -> {
                            standartUnitPrice = 0.41 + 0.90;
                            promUnitPrice = 0;
                            priceOrderedProducts = standartUnitPrice * quantity;
                            lineTotal = priceOrderedProducts - promUnitPrice;
                        }
                        case 4 -> {
                            standartUnitPrice = 0.60 + 1.00;
                            int numberFreeChips = quantity / 3;
                            priceOrderedProducts = standartUnitPrice * quantity;
                            promUnitPrice = (priceOrderedProducts - (numberFreeChips * standartUnitPrice)) / quantity;
                            lineTotal = priceOrderedProducts - (numberFreeChips * standartUnitPrice);
                        }
                    }

                    totalPriceBefClDisc += lineTotal;

                    for (Products products : Products.values()
                    ) {
                        if (products.getProduct_id() == productID) {
                            productName = products.getProduct_name();
                        }
                    }
                    if (promUnitPrice > 0){
                        System.out.printf("%-20s | %-8s | EUR%16.2f | EUR%19.5f | EUR%19.2f %n",productName, quantity, standartUnitPrice, promUnitPrice, lineTotal);
                    }
                    else {
                        System.out.printf("%-20s | %-8s | EUR%16.2f | %-22s | EUR%19.2f %n",productName, quantity, standartUnitPrice, "", lineTotal);
                    }
                }else {
                    System.out.println("Products are 4, please provide another ID");
                }

            }

            switch (clientID) {
                case 1 :
                    basicClDisc = 5;
                    basicClDiscPrice = totalPriceBefClDisc * (basicClDisc / 100.00);
                    if (totalPriceBefClDisc > 30000) {
                        additionalVolDisc = 2;
                        additionalVolDiscPrice = basicClDiscPrice * (additionalVolDisc / 100.0);
                    }
                    break;
                case 2 :
                    basicClDisc = 4;
                    basicClDiscPrice = totalPriceBefClDisc*(basicClDisc/100.00);
                    if (totalPriceBefClDisc > 10000 && totalPriceBefClDisc <=30000) {
                        additionalVolDisc = 1;
                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                    } else if (totalPriceBefClDisc > 30000) {
                        additionalVolDisc = 2;
                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                    }
                    break;
                case 3 :
                    basicClDisc = 3;
                    basicClDiscPrice = totalPriceBefClDisc*(basicClDisc/100.00);
                    if (totalPriceBefClDisc > 10000 && totalPriceBefClDisc <=30000) {
                        additionalVolDisc = 1;
                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                    } else if (totalPriceBefClDisc > 30000) {
                        additionalVolDisc = 3;
                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                    }
                    break;
                case 4 :
                    basicClDisc = 2;
                    basicClDiscPrice = totalPriceBefClDisc*(basicClDisc/100.00);
                    if (totalPriceBefClDisc > 10000 && totalPriceBefClDisc <=30000) {
                        additionalVolDisc = 3;
                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                    } else if (totalPriceBefClDisc > 30000) {
                        additionalVolDisc = 5;
                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                    }
                    break;
                case 5 :
                    if (totalPriceBefClDisc > 10000 && totalPriceBefClDisc <=30000) {
                        additionalVolDisc = 5;
                        additionalVolDiscPrice = totalPriceBefClDisc*(additionalVolDisc/100.0);
                    } else if (totalPriceBefClDisc > 30000) {
                        additionalVolDisc = 7;
                        additionalVolDiscPrice = totalPriceBefClDisc*(additionalVolDisc/100.0);
                    }
                    break;
            }

            orderTotalAmount = totalPriceBefClDisc - basicClDiscPrice - additionalVolDiscPrice;

            System.out.printf("%n%-40s %s %.2f%n","Total Before Client Discounts:","EUR",totalPriceBefClDisc);
            if (basicClDisc > 0){
                System.out.printf("%s%d%%:%-12s %s %.2f%n","Basic Client Discount at ",basicClDisc,"","EUR", basicClDiscPrice);
            }
            if (additionalVolDisc > 0){
                System.out.printf("%s%d%%:%-7s %s %.2f%n","Additional Volume Discount at ",additionalVolDisc,"","EUR",additionalVolDiscPrice);
            }
            System.out.printf("%-40s %s %.2f","Order Total Amount:","EUR", orderTotalAmount);
        }else {
            System.out.println("Clients are 5, please provide another ID");
        }
    }
}