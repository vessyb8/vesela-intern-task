package org.example;

public enum Clients {
    DISTRIBUTION(1, "ABC Distribution"),
    FOODS(2, "DEF FOODS"),
    TRADE(3, "GHI Trade"),
    KIOSKS(4, "JKL Kiosks"),
    VENDING(5, "MNO Vending");

    private int client_id;
    private String client_name;

    Clients(int client_id, String client_name) {
        this.client_id = client_id;
        this.client_name = client_name;
    }

    public int getClient_id() {
        return this.client_id;
    }

    public String getClient_name() {
        return this.client_name;
    }
}
